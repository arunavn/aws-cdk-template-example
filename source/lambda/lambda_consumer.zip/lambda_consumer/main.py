def lambda_handler(*args, **kwargs):
    print("hello")